# Smart Campus Suite

ITA0303 – Mobile Computing  
Student: Mahitha.S  
Register No.: 192521065  
Faculty: Mrs. B. Abisha  
Department: Computer Science and Engineering

## Modules
- Student Login
- Smart Campus Dashboard
- Attendance
- Attendance History
- Offline Mode
- Campus Security Alerts
- Send Security Alert
- Alert Location
- Alert Details
- Network Recovery / Synchronization

## Technology
- Android
- Kotlin
- Jetpack Compose
- ViewModel-style state handling
- Local/offline state simulation
- Material 3 UI

## How to run
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Run the `app` configuration on an Android emulator/device.
4. The application starts with the Smart Campus login screen.

## GitHub
Create a repository named `smart-campus-suite`, then upload the complete project folder.

> Note: This is an academic prototype. Backend services, real authentication, push notification infrastructure and production database replication are represented through local prototype logic.
