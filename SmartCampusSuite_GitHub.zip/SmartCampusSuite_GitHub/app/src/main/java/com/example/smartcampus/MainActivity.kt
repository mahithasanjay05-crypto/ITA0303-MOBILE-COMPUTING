package com.example.smartcampus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CampusBlue = Color(0xFF123B67)
private val CampusLight = Color(0xFFEAF2F8)

data class Attendance(val subject: String, val present: Int, val total: Int)
data class Alert(val type: String, val message: String, val location: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartCampusApp() }
    }
}

@Composable
fun SmartCampusApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("Dashboard") }
    var offline by remember { mutableStateOf(false) }

    val attendance = remember {
        mutableStateListOf(
            Attendance("Mobile Computing", 18, 20),
            Attendance("Database Systems", 17, 20),
            Attendance("Computer Networks", 16, 20)
        )
    }
    val alerts = remember {
        mutableStateListOf(
            Alert("HIGH", "Emergency drill at Main Block", "Main Block"),
            Alert("MEDIUM", "Restricted area notice", "Library Block")
        )
    }

    if (!loggedIn) {
        LoginScreen { loggedIn = true }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Smart Campus") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CampusBlue,
                    titleContentColor = Color.White
                ),
                actions = {
                    Text(
                        if (offline) "OFFLINE" else "ONLINE",
                        color = Color.White,
                        modifier = Modifier.padding(end = 16.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Dashboard", "Attendance", "Alerts", "Offline").forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item },
                        icon = { Text(item.first().toString()) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (screen) {
                "Dashboard" -> DashboardScreen(
                    onAttendance = { screen = "Attendance" },
                    onAlerts = { screen = "Alerts" },
                    onOffline = { screen = "Offline" }
                )
                "Attendance" -> AttendanceScreen(attendance, offline)
                "Alerts" -> AlertScreen(alerts)
                "Offline" -> OfflineScreen(offline) { offline = !offline }
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("SMART CAMPUS", color = CampusBlue, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Your Campus. In Your Hand.", fontSize = 15.sp)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(value = "192521065", onValueChange = {}, label = { Text("Student ID") })
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = "••••••••", onValueChange = {}, label = { Text("Password") })
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onLogin,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CampusBlue)
        ) { Text("LOGIN") }
    }
}

@Composable
fun DashboardScreen(onAttendance: () -> Unit, onAlerts: () -> Unit, onOffline: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Welcome, Mahitha.S", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Student • 192521065")
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Attendance", onAttendance, Modifier.weight(1f))
                ActionCard("Alerts", onAlerts, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Offline", onOffline, Modifier.weight(1f))
                ActionCard("Library", {}, Modifier.weight(1f))
            }
        }
        item {
            InfoCard("Today's Schedule", "Mobile Computing • 09:00 AM • Room 301")
        }
        item {
            InfoCard("Campus Navigation", "Library • CSE Block • Auditorium")
        }
        item {
            InfoCard("Security", "1 high-priority campus alert requires attention.")
        }
    }
}

@Composable
fun ActionCard(title: String, action: () -> Unit, modifier: Modifier) {
    Card(modifier = modifier, onClick = action) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = CampusBlue, fontWeight = FontWeight.Bold)
            Text("Open")
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CampusLight)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = CampusBlue)
            Spacer(Modifier.height(5.dp))
            Text(body)
        }
    }
}

@Composable
fun AttendanceScreen(data: List<Attendance>, offline: Boolean) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Attendance", fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        item {
            InfoCard(
                "Synchronization",
                if (offline) "Offline: records will be synchronized automatically." else "✓ Latest server state synchronized"
            )
        }
        items(data) { item ->
            val percent = item.present * 100 / item.total
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(item.subject, fontWeight = FontWeight.Bold)
                    Text("${item.present} / ${item.total} classes")
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { percent / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("$percent%")
                }
            }
        }
        item {
            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = CampusBlue)
            ) { Text("MARK ATTENDANCE") }
        }
    }
}

@Composable
fun AlertScreen(alerts: List<Alert>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Security Alerts", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
            ) { Text("SEND SECURITY ALERT") }
        }
        items(alerts) { alert ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(alert.type, color = if (alert.type == "HIGH") Color.Red else CampusBlue, fontWeight = FontWeight.Bold)
                    Text(alert.message, fontWeight = FontWeight.Bold)
                    Text("Location: ${alert.location}")
                    Text("Status: Active")
                }
            }
        }
    }
}

@Composable
fun OfflineScreen(offline: Boolean, toggle: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(if (offline) "☁" else "✓", fontSize = 60.sp)
        Text(if (offline) "You are currently offline" else "You are online", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(if (offline) "Data is saved locally and will sync when online." else "Network connection is available.")
        Spacer(Modifier.height(25.dp))
        Button(
            onClick = toggle,
            colors = ButtonDefaults.buttonColors(containerColor = CampusBlue)
        ) { Text(if (offline) "RESTORE NETWORK" else "SIMULATE OFFLINE") }
    }
}
